"""
The Run_Method Module contains methods to execute and process the output of IWS EPANET and EPA-SWMM Files
using one of the  eight methods we studied
"""
global wntr
global np
global pd
global re 
global math
global mpl
global figure
global plt
global timeit

import wntr
import numpy as np 
import pandas as pd
import re
import math
import matplotlib as mpl
from matplotlib import figure
import matplotlib.pyplot as plt
import timeit 

def CVRes(dir:str,file:str,Hmin:float,Hdes:float,output:str='S',low_percentile:int=10,high_percentile:int=90,save_outputs:bool=True,time_execution:bool=False,n_iterations:int=100,plots=True):
    """
    Executes an IWS EPANET file that uses the unrestricted method CV-Res.

    Parameters
    -----------
    dir (str): Directory in which origin file is located
    file (str): Filename with extension of origin file
    Hmin (float): Value of the minimum pressure Hmin used for Pressure-Dependent Analysis (PDA)
    Hdes (float): Value of the desired pressure Hmin used for Pressure-Dependent Analysis (PDA)
    output (str): specify output to process. Default: Satisfaction Ratio. Other supported outputs include 'P' for Pressure
    low_percentile (int): value for the low percentile statistic (default 10th percentile) representing disadvantaged consumers
    high_percentile (int): value for the high percentile statistic (default 90th percentile) representing disadvantaged consumers
    save_outputs (bool): Save processed output and statistices (mean, median an percentiles) as CSV files. Default: True.
    time_execution (bool): Optionally times the execution of the EPANET file. default= False
    n_iterations (int): number of iterations for averaging execution time. Default=100
    plots (bool): Display mean and range plots. default: True

    Returns: None. Saves output file in same directory
    """
    assert 0 < low_percentile <100, "Percentile must be between 0 and 100"
    assert 0 < high_percentile <100, "Percentile must be between 0 and 100"
    assert output in ['S','P'], "Specify Supported Output Type: S for Satisfaction or P for Pressures"
    assert 0<=Hmin<=Hdes, "Hdes must be higher than Hmin and both must be >= 0"

    name_only=file[0:-4]
    print("Selected File: ",name_only)
    abs_path=dir+file

    # create network model from input file
    network = wntr.network.WaterNetworkModel(abs_path)

    demand_links=[]        #list of pipes connected to demand nodes only
    lengths=[]
    diameters=[]
    hwcoeff=[]

    for link in network.links():
        if re.search('^PipeforNode',link[1].name):
            demand_links.append(link[1].name)
            lengths.append(link[1].length)
            diameters.append(link[1].diameter)
            hwcoeff.append(link[1].roughness)
    # Get the supply duration in minutes (/60) as an integer
    supply_duration=int(network.options.time.duration/60)

    lengths=np.array(lengths)
    diameters=np.array(diameters)
    hwcoeff=np.array(hwcoeff)

    head_diff=Hdes-Hmin
    desired_demands=(head_diff/lengths*hwcoeff**1.852*diameters**4.8704/10.67)**0.54

    # run simulation
    sim = wntr.sim.EpanetSimulator(network)
    # store results of simulation
    results=sim.run_sim()

    if time_execution:
        __time_simulation__(abs_path,n_iterations)

    timesrs_output=pd.DataFrame()

    if output=='S':
        timesrs_output[0]=results.link['flowrate'].loc[0,:]
        for i in range(1,supply_duration+1):
            # Extract Node Pressures from Results
            timesrs_output=pd.concat([timesrs_output,results.link['flowrate'].loc[i*60,:]],axis=1)

        # Transpose DataFrame such that indices are time (sec) and Columns are each Node
        timesrs_output=timesrs_output.T
        # Filter DataFrame for Columns that contain Data for demand nodes only i.e., Tanks in STM
        timesrs_output=timesrs_output.filter(demand_links)

        # Calculates the total demand volume in the specified supply cycle
        desired_volumes=[]
        # Loop over each desired demand
        for demand in desired_demands:
            # Append the corresponding desired volume (cum) = demand (LPS) *60 sec/min * supply duration (min) / 1000 (L/cum)
            desired_volumes.append(float(demand)*60*float(supply_duration))

        # Combine demands (LPS) to their corresponding desired volume (cum)
        desired_volumes=dict(zip(demand_links,desired_volumes))

        # Initalized DataFrame for storing volumes received by each demand node as a timeseries
        timesrs_processed=pd.DataFrame(index=timesrs_output.index,columns=desired_volumes.keys())
        # Set Initial volume for all consumers at 0
        timesrs_processed.iloc[0,:]=0

        # Loop over consumers and time steps to add up volumes as a percentage of total desired volume (Satisfaction Ratio)
        for timestep in list(timesrs_processed.index)[1:]:
            for node in timesrs_processed.columns:
                # Cummulatively add the percent satisfaction ratio (SR) increased each time step
                ## SR at time t = SR at time t-1 + demand at time t-1 (cms) *60 seconds per time step/ Desired Demand Volume (cum)
                timesrs_processed.at[timestep,node]=timesrs_processed.at[timestep-60,node]+timesrs_output.at[timestep-60,node]*60/desired_volumes[node]*100
    elif output=='P':
        timesrs_output[0]=results.node['pressure'].loc[0,:]
        for i in range(1,supply_duration+1):

            # Extract Node Pressures from Results
            timesrs_output=pd.concat([timesrs_output,results.node['pressure'].loc[i*60,:]],axis=1)

        # Transpose DataFrame such that indices are time (sec) and Columns are each Node
        timesrs_output=timesrs_output.T
        # Filter DataFrame for Columns that contain Data for demand nodes only i.e., Tanks in STM
        node_list=[]
        for column in timesrs_output.columns:
            if re.search('^AR',column):
                node_list.append(column[2:])
        # Filter DataFrame for Columns that contain Data for demand nodes only i.e., Tanks in STM
        timesrs_processed=timesrs_output.filter(node_list,axis=1)
    
    # Intialize Series for storing statistics
    mean=pd.Series(dtype='float64')
    median=pd.Series(dtype='float64')
    low_percentile_series=pd.Series(dtype='float64')
    high_percentile_series=pd.Series(dtype='float64')

    # Loop over each row (time step) in the results and calculate values of mean, median, low and high percentiles
    for row in timesrs_processed.index:
        mean.loc[row]=np.mean(timesrs_processed.loc[row,:])
        low_percentile_series.loc[row]=np.percentile(timesrs_processed.loc[row,:],low_percentile)
        median.loc[row]=np.percentile(timesrs_processed.loc[row,:],50)
        high_percentile_series.loc[row]=np.percentile(timesrs_processed.loc[row,:],high_percentile)
    
    if save_outputs==True:
    # Saves Entire Results DataFrame as Filename_TimeSeries.csv in the same path
        timesrs_processed.to_csv(dir+name_only+"_TimeSeries.csv")

        # Saves Mean Satisfaction with time as Filename_Means.csv in the same path
        mean.to_csv(dir+name_only+"_Means.csv")

        # Saves Median Satisfaction with time as Filename_Medians.csv in the same path
        median.to_csv(dir+name_only+"_Medians.csv")

        # Saves the specified low percentile (XX) values with time as Filename_XXthPercentile.csv in the same path
        low_percentile_series.to_csv(dir+name_only+"_"+str(low_percentile)+"thPercentile.csv")

        # Saves the specified high percentile (YY) values with time as Filename_YYthPercentile.csv in the same path
        high_percentile_series.to_csv(dir+name_only+"_"+str(high_percentile)+"thPercentile.csv")
    
    if plots:
        mpl.rcParams['figure.dpi'] = 450
        font = {'family' : 'Times',
                'weight' : 'bold',
                'size'   : 3}
        mpl.rc('font', **font)
        mpl.rc('xtick', labelsize=3)
        mpl.rcParams['axes.linewidth'] = 0.5

        # Prepping an xaxis with hr format
        supply_duration_hr=supply_duration/60
        xaxis=np.arange(0,supply_duration_hr+0.00001,1/60)
        
        fig, ax=plt.subplots()
        # Change figure size (and aspect ratio) by adjusting height and width here
        fig.set_figwidth(1.5)
        fig.set_figheight(1)

        if output=='S':

            ax.set_title('Average Demand Satisfaction with Time')
            ax.set_xlim(0,supply_duration_hr)
            ax.set_ylim(0,max(mean))
            ax.set_xticks(np.arange(0,supply_duration_hr+1,4))
            ax.set_xticks(np.arange(0,supply_duration_hr+1,1),minor=True)
            ax.set_yticks(np.arange(0,max(mean)+1,25))
            ax.tick_params(width=0.5)

            # Data to be plotted: Mean as a percentage 
            # Change color by changing the string next to c= and linewidth by value
            line1,=ax.plot(xaxis,mean, c='#d73027',linewidth=0.5)
            plt.xlabel('Supply Time (hr)')
            plt.ylabel('Satisfaction Ratio (%)')
            ax.spines['top'].set_visible(False)
            ax.spines['right'].set_visible(False)
            plt.show

            fig, ax=plt.subplots()
            fig.set_figwidth(1.5)
            fig.set_figheight(1)

            ax.set_title('Range of Demand Satisfaction with Time')
            ax.set_xlim(0,supply_duration_hr)
            ax.set_ylim(0,max(high_percentile_series)+1)
            ax.set_xticks(np.arange(0,supply_duration_hr+1,4))
            ax.set_xticks(np.arange(0,supply_duration_hr+1,1),minor=True)
            ax.set_yticks(np.arange(0,max(high_percentile_series+1),25))
            ax.tick_params(width=0.5)

            line1,=ax.plot(xaxis,mean, c='#fee090',linewidth=0.5)
            plt.fill_between(xaxis, y1=low_percentile_series, y2=high_percentile_series, alpha=0.4, color='#fee090', edgecolor=None)
            plt.xlabel('Supply Time (hr)')
            plt.ylabel('Satisfaction Ratio (%)')
            ax.spines['top'].set_visible(False)
            ax.spines['right'].set_visible(False)
            plt.show

        elif output=='P':
            ax.set_title('Average Pressure with Time')
            ax.set_xlim(0,supply_duration_hr)
            ax.set_ylim(0,max(mean)+1)
            ax.set_xticks(np.arange(0,supply_duration_hr+1,4))
            ax.set_xticks(np.arange(0,supply_duration_hr+1,1),minor=True)
            ax.set_yticks(np.arange(0,max(mean)+1,math.ceil((max(mean)-0)/5)))
            ax.tick_params(width=0.5)

            # Data to be plotted: Mean as a percentage (hence the multiplication by 100)
            # Change color by changing the string next to c= and linewidth by value
            line1,=ax.plot(xaxis,mean, c='#fee090',linewidth=0.5)
            plt.xlabel('Supply Time (hr)')
            plt.ylabel('Pressure (m)')
            # Optional: show grid or turn on and off spines (Plot box sides)
            # ax.grid(visible=True,which='both')
            ax.spines['top'].set_visible(False)
            ax.spines['right'].set_visible(False)
            plt.show

            fig, ax=plt.subplots()
            fig.set_figwidth(1.5)
            fig.set_figheight(1)

            ax.set_title('Range of Pressure with Time')
            ax.set_xlim(0,supply_duration_hr)
            ax.set_ylim(0,max(high_percentile_series)+1)
            ax.set_xticks(np.arange(0,supply_duration_hr+1,4))
            ax.set_xticks(np.arange(0,supply_duration_hr+1,1),minor=True)
            ax.set_yticks(np.arange(0,max(high_percentile_series)+1,math.ceil((max(high_percentile_series)-0)/5)))
            ax.tick_params(width=0.5)

            line1,=ax.plot(xaxis,mean, c='#fee090',linewidth=2)
            ax.tick_params(axis='both',labelsize='8')
            plt.fill_between(xaxis, y1=low_percentile_series, y2=high_percentile_series, alpha=0.4, color='#fee090', edgecolor=None)
            plt.xlabel('Supply Time (hr)')
            plt.ylabel('Nodal Pressure (m)')
            ax.spines['top'].set_visible(False)
            ax.spines['right'].set_visible(False)
            plt.show()
            


def CVTank(dir:str,file:str,output:str='S',low_percentile:int=10,high_percentile:int=90,save_outputs:bool=True,time_execution:bool=False,n_iterations:int=100,plots=True):
    """
    Executes an IWS EPANET file that uses the volume-restricted method CV-Res.

    Parameters
    -----------
    dir (str): Directory in which origin file is located
    file (str): Filename with extension of origin file
    output (str): specify output to process. Default: Satisfaction Ratio. Other supported outputs include 'P' for Pressure
    low_percentile (int): value for the low percentile statistic (default 10th percentile) representing disadvantaged consumers
    high_percentile (int): value for the high percentile statistic (default 90th percentile) representing disadvantaged consumers
    save_outputs: Save processed output and statistices (mean, median an percentiles) as CSV files. Default: True.
    time_execution (Boolean): Optionally times the execution of the EPANET file. default= False
    n_iterations (int): number of iterations for averaging execution time. Default=100
    plots (bool): Display mean and range plots. default: True

    Returns: None. Saves output file in same directory
    """

    assert 0 < low_percentile <100, "Percentile must be between 0 and 100"
    assert 0 < high_percentile <100, "Percentile must be between 0 and 100"
    assert output in ['S','P'], "Specify Supported Output Type: S for Satisfaction or P for Pressures"

    name_only=file[0:-4]
    print("Selected File: ",name_only)
    abs_path=dir+file

    # create network model from input file
    network = wntr.network.WaterNetworkModel(abs_path)

    ## Extract Supply Duration from .inp file
    supply_duration=int(network.options.time.duration/60)    # in minutes

    # run simulation
    sim = wntr.sim.EpanetSimulator(network)
    # store results of simulation
    results=sim.run_sim()

    if time_execution:
        __time_simulation__(abs_path,n_iterations)
    








def __time_simulation__(abs_path:str,n_iterations:int):
    """
    Times the execution of an EPANET file for a given number of iterations

    abs_path (str): input file path
    n_iterations (int): number of iterations to time execution
    """
    # Statement to be timed: read filename, create network model, run network simulation
    timed_lines='inp_file='+"'"+abs_path+"'"
    timed_lines=timed_lines+'''
    wn = wntr.network.WaterNetworkModel(inp_file) 
    wntr.sim.EpanetSimulator(wn)
    '''

    # Time and average over number of iterations
    time=np.round(timeit.timeit(stmt=timed_lines,setup='import wntr',number=n_iterations)/n_iterations*1000,decimals=2)
    print("Time taken for ",file,' is ', time, 'milliseconds per run')